// include all packages
var express = require("express");
// initialize the express app
var app = express();
// allow express to expose the public directory API to allow Marketing Cloud
//  to access their custom activity framework objects
app.use(express.static('public'));
// listen to port 3000 (local) or to the port designated by the Azure
// services
var server = app.listen(process.env.PORT || 3000, function () {
    console.log("Listening on port %s...", server.address().port);
});
